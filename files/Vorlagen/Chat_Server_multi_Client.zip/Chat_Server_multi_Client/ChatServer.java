import ea.*;
/**
 * Einfache DEMO-Klasse zum Demonstrieren des Server-Sockets.
 * 
 * @author      michl andonie
 * @version     2013-09-07
 */
public class ChatServer
implements Empfaenger 
{
    
    Server echo;
    
    
    /**
     * EchoServer Konstruktor
     *
     */
    public ChatServer() 
    {
         echo = new Server( 44444 );
         echo.globalenEmpfaengerSetzen( this );
    }
    
    
    /**
     * EchoServer Konstruktor
     * 
     * @param   port    Der Port, auf dem der Server lauschen soll
     *
     */
    public ChatServer( int port ) 
    {
         echo = new Server( port );
         echo.globalenEmpfaengerSetzen( this );
    }
    
    
    
    @Override
    public void empfangeString( String s ) 
    {
        // 3 verschiedene Signaltypen:
            // 1) Anmeldungen ('a' + name)
            // 2) Chat-Nachricht an alle Clients ('c' + name + '|' + nachricht)
            // 3) Abmeldungen ('q' + name)
        switch( s.charAt(0) ) 
        {
            case 'a':
                echo.sendeString( s.substring(1) + " hat den Chatroom betreten." );
                break;
            case 'c':
                String name = s.substring( 1 , s.indexOf("|") );
                String nachricht = s.substring( s.indexOf("|") + 1 );
                echo.sendeString( "Neue Nachricht von " + name + ": " + nachricht );
                break;
            case 'q':
                echo.sendeString( s.substring(1) + " hat den Chat verlassen." );
                break;
            default:
                //FEHLER
                System.out.println( "Dieser Signaltyp war nicht vorgesehen!" );
                break;
        }
    }
    
    @Override
    public void empfangeByte( byte b ) 
    {
        //
    }
    
    @Override
    public void empfangeInt( int i ) 
    {
        //
    }
    
    @Override
    public void empfangeChar( char c ) 
    {
        //
    }
    
    @Override
    public void empfangeDouble( double d ) 
    {
        //
    }
    
    @Override
    public void empfangeBoolean( boolean b ) 
    {
        //
    }
    
    @Override
    public void verbindungBeendet() 
    {
        // Das soll getan werden, wenn die Gegenstelle die Verbindung beendet hat
    }
    
}
