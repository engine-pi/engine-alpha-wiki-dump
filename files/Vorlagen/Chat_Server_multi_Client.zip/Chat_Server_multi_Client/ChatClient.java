import ea.*;

/**
 * Einfache DEMO-Klasse zur Demonstration des Client-Sockets
 * 
 * @author      michl andonie
 * @version     2013-09-07
 */
public class ChatClient
implements Empfaenger 
{
    
    Client client;
    
    final String name;
    
    
    
    /**
     * EchoClient Konstruktor
     * 
     * @param   name    Der Name des Users
     *
     */
    public ChatClient( String name ) 
    {
        this( name , "localhost" , 44444 );
    }
    
    
    /**
     * EchoClient Konstruktor
     * 
     * @param   name    Der Name des Users
     * @param   ip      IP-Adresse des Servers
     *
     */
    public ChatClient( String name , String ip ) 
    {
        this( name , ip , 44444 );
    }
    
    
    /**
     * EchoClient Konstruktor
     * 
     * @param   name    Der Name des Users
     * @param   ip      Die IP-Adresse des Servers
     * @param   port    Der Port, auf dem der Server lauscht
     *
     */
    public ChatClient( String name , String ip , int port ) 
    {
        this.name = name;
        // Der Client soll sich mit dem Server-Socket verbinden
        client = new Client( name , ip, port );
        // Observer-Pattern: Ich melde mich als Empfaenger an
        client.empfaengerHinzufuegen( this );
        
        client.sendeString( 'a' + name );
    }
    
    
    
    
    public void sendeChatNachricht( String nachricht ) 
    {
        client.sendeString( 'c' + name + '|' + nachricht );
    }
    
    
    
    public void beendeChatVerbindung() 
    {
        client.sendeString( 'q' + name );
        client.beendeVerbindung();
    }
    
    
    
    @Override
    public void empfangeString( String s ) 
    {
        // Als Client schreibe ich das Emfangene einfach auf die Konsole
        System.out.println( s );
    }
    
    @Override
    public void empfangeByte( byte b ) 
    {
        //
    }
    
    @Override
    public void empfangeInt( int i ) 
    {
        //
    }
    
    @Override
    public void empfangeChar( char c ) 
    {
        //
    }
    
    @Override
    public void empfangeDouble( double d ) 
    {
        //
    }
    
    @Override
    public void empfangeBoolean( boolean b ) 
    {
        //
    }
    
    @Override
    public void verbindungBeendet() 
    {
        // Das soll getan werden, wenn die Verbindung von der Gegenstelle beendet wurde
    }
    
}
