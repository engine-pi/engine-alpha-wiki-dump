import ea.edu.net.*;

/**
 * EDU-Variante eines Server-Sockets - reduziert auf die wesentlichen Methoden. 
 * Dieser Server kann sich nur mit einem Client verbinden.
 * 
 * @author  mike ganhorn
 * 
 * @version 2013-09-08
 */
public class SERVER
extends SimplerServer 
{
    
    private String ss;
    
    
    /**
     * SERVER Konstruktor
     *
     * @param   port    Port, auf dem der Server lauschen soll.
     */
    public SERVER( int port ) 
    {
        super( port );
    }
    
    
    /**
     * Methode zum Lauschen auf eine Nachricht des Clients
     *
     * @return  Der vom Client empfangene String
     */
    @Override
    public String lauschen() 
    {
        return super.lauschen();
    }
    
    
    /**
     * Methode zum Senden einer Nachricht an den Client
     *
     * @param   s   String, der zum Client gesendet werden soll
     */
    public void senden( String s ) 
    {
        super.senden( s );
    }
    
    
    /**
     * Methode zum Empfangen einer bereits vom Client an den Server gesendeten Nachricht
     *
     * @return  Der vom Client empfangene String
     */
    public String empfangen() 
    {
        return super.lauschen();
    }
    
}
