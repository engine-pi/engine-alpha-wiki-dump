import ea.edu.net.*;

/**
 * EDU-Variante eines Client-Sockets - reduziert auf die wesentlichen Methoden.
 * 
 * @author      mike ganshorn
 * 
 * @version     2013-09-08
 */
public class CLIENT
extends SimplerClient 
{
        
    
    /**
     * CLIENT Konstruktor fuer Kommunikation mit localhost.
     *
     * @param   port    Port, auf dem der Server auf Verbindungen lauscht
     */
    public CLIENT( int port ) 
    {
        this( "localhost" , port );
    }
    
    
    /**
     * CLIENT Konstruktor fuer Kommunikation mit anderem Host.
     *
     * @param   ip      IP-Adresse des Servers
     * @param   port    Port, auf dem der Server auf Verbindungen lauscht
     */
    public CLIENT( String ip , int port ) 
    {
        super( "" , ip , port );
    }
    
    
    /**
     * Methode zum Lauschen auf dem Socket, bis eine Nachricht vom Server kommt.
     *
     * @return      Der vom Server gesendete String
     */
    @Override
    public String lauschen() 
    {
        return super.lauschen();
    }
    
    
    
    /**
     * Methode zum Empfangen einer bereits vom Server an den Client gesendeten Nachricht.
     *
     * @return      Der vom Server gesendete String
     */
    public String empfange() 
    {
        return super.lauschen();
    }
    
    
    /**
     * Methode zum Senden einer Nachricht an den Server.
     *
     * @param   s   String, der an den Server gesendet werden soll
     */
    public void senden( String s ) 
    {
        super.senden( s );
    }
}
