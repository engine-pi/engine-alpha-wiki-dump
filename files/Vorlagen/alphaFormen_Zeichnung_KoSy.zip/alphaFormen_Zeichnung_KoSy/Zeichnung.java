
public class Zeichnung
{
    // Zuerst werden die Bauteile deklariert ("bestellt"):
    // Man nennt den Datentyp und vergibt einen Namen
    
    private KREIS sonne;
    private RECHTECK wand;
    private DREIECK dach;
    
    
    // Konstruktor der Klasse Zeichnung
    // Hier werden die Bauteile initialisiert:
    // erst erzeugt und dann gestaltet
    public Zeichnung()
    {
        this.sonne = new KREIS();
        this.sonne.setzeFarbe("gelb");
        this.sonne.setzeMittelpunkt( 700 , 100 );
        
        
        
        this.wand = new RECHTECK();
        this.wand.setzeFarbe("blau");
        
        
        
        this.dach = new DREIECK();
        
        
        
        
        
    }
    
}