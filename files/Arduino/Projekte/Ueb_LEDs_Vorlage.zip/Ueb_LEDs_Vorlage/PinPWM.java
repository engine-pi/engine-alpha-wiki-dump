import org.firmata4j.*;
import java.io.*;

/**
 * PinPWM repraesentiert einen Pulsweiten-Modulations-Pin am Arduino. 
 * Unter Pulsweiten-Modulation versteht man einen OUTPUT Pin, der
 * eine periodische Rechteck-Spannung betreibt. 
 * Es wechselt periodisch HIGH und LOW ab. 
 * Dabei kann man einstellen, welchen Anteil 
 * das HIGH an einer ganzen Periode haben soll: 
 *        0   kein HIGH, nur LOW
 *       20   20 Prozent HIGH, dann 80 Prozent LOW
 *       70   70 Prozent HIGH, dann 30 Prozent LOW
 *      100   nur HIGH, kein LOW
 * 
 * Damit kann man   z.B.    LEDs dimmen 
 *                          Motor-Treiber (H-Bruecken) ansteuern
 *                          Ausgangs-Spannungen von 0V bis 5V "simulieren"
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.1 (2017-08-07)    Untertuetzung fuer Mega
 *              1.0 (2017-01-05)    initial
 */
public class PinPWM
{
    private Pin pwm_pin;
    // Anteil HIGH an einer Periode in Prozent
    private int duty_percentage;

    
    /**
     * Konstruktor der Klasse PinPWM.
     * 
     * @param   pin     Nummer des Pins am Arduino 
     *                  ( 3 , 5 , 6 , 9 , 10 , 11 beim UNO ) , 
     *                  ( 2-13 , 44-46 beim Mega )
     */
    public PinPWM( int pin )
    {
        this.pwm_pin = Arduino.getDevice().getPin( pin );
        try
        {
            this.pwm_pin.setMode( Pin.Mode.PWM );
            this.pwm_pin.setValue( 0 );
            this.duty_percentage = 0;
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }

    
    
    /**
     * Setzt den Anteil HIGH einer Periode (Duty Cycle) in Prozent.
     *
     * @param   percentage  Prozentwert von 0 bis 100 fuer den HIGH-Anteil
     */
    public void setDutyCyclePercentage( int percentage )
    {
        if  ( percentage >= 0  &&  percentage <= 100 )
        {
            try
            {
                this.pwm_pin.setValue( percentage );
                this.duty_percentage = percentage;
            }
            catch ( IOException e )
            {
                e.printStackTrace();
            }
        }
    }
    
    
    
    /**
     * Gibt den aktuellen Anteil HIGH einer Periode (Duty Cycle) in Prozent zurueck.
     *
     * @return      Pozentwert des Anteils HIGH an einer Periode
     */
    public int getDutyCyclePercentage()
    {
        return this.duty_percentage;
    }
}
