import org.firmata4j.*;
import java.io.*;


/**
 * PinOutput repreasentiert einen digitalen Output-Pin am Arduino 
 * (2-13 beim UNO) (2-53 beim Mega).
 * 
 * @author      mike_ganshorn@yahoo.de
 * 
 * @version     1.1 (2017-08-07)    Unterstuetzung fuer Mega
 *              1.0 (2017-01-01)    initial
 */
public class PinOutput
{
    private Pin output_pin;
    private boolean state;

    
    /**
     * Konstruktor der Klasse PinOutput
     * 
     * @param   pin     Nummer des Pins am Arduino (2-13 beim UNO) (2-53 beim Mega)
     */
    public PinOutput( int pin )
    {
        this.output_pin = Arduino.getDevice().getPin( pin );
        try
        {
            this.output_pin.setMode( Pin.Mode.OUTPUT );
            this.output_pin.setValue( 0 );
            this.state = false;
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
        
    }

    
    /**
     * Prueft ob der aktuelle Status HIGH ist
     *
     * @return  true fuer HIGH , false fuer LOW
     */
    public boolean isHigh()
    {
        return this.state;
    }
    
    
    /**
     * Prueft ob der aktuelle Status LOW ist
     *
     * @return  true fuer LOW , false fuer HIGH
     */
    public boolean isLow()
    {
        return !this.state;
    }
    
    
    /**
     * Setzt das Ausgangs-Signal auf HIGH (5V)
     */
    public void high()
    {
        try
        {
            this.output_pin.setValue( 1 );
            this.state = true;
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    
    /**
     * Setzt das Ausgangs-Signal auf LOW (GND)
     */
    public void low()
    {
        try
        {
            this.output_pin.setValue( 0 );
            this.state = false;
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    
    /**
     * Wechselt den aktuellen Zustand des Ausgangs-Signals ( LOW-->HIGH bzw. HIGH-->LOW )
     */
    public void toggle()
    {
        if  ( isHigh() )
        {
            low();
        }
        else
        {
            high();
        }
    }
}
