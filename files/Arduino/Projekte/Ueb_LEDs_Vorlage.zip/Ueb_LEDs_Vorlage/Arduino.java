import org.firmata4j.*;
import org.firmata4j.firmata.FirmataDevice;
import java.io.*;
import org.slf4j.*;
import com.fazecast.jSerialComm.*;


/**
 * Klasse Arduino repraesentiert ein Arduino (Uno / Mega). 
 * Die Klasse wird nicht direkt vom Anwender verwendet, 
 * sondern nur intern durch andere Klassen.
 * Die Unterstuetzung des Arduino Mega ist noch experimental !!!
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.2 (2017-08-07)    Arduino Mega wird experimentell unterstuetzt (InterruptedException --> geht trotzdem?)
 *              1.1 (2017-01-06)    Arduino wird automatisch erkannt    (Idee nach StREFin Manuela Deuerlein)
 *              1.0 (2017-01-01)    initial
 */
public class Arduino
{
    static IODevice device;
    
    // Konstanten zur besseren Lesbarkeit des Codes
    public static int INPUT = 0;
    public static int OUTPUT = 1;
    public static int ANALOG = 2;
    public static int PWM = 3;
    public static int SERVO = 4;
    public static int PULLUP = 5;

    public static int HIGH = 1;
    public static int LOW = 0;

//     static
//     {
//         setup();
//     }

    
    
    
    /**
     * Konstruktor der Klasse Arduino
     */
    private Arduino()
    {
        setup();
    }

    
    
    /**
     * Initiales Setup. 
     * Vor Aufruf dieser Methode geht gar nichts!
     */
    public static void setup()
    {
        // alle angschossenen Seriellen (z.B. USB) Geraete suchen
        SerialPort[] serialPorts = SerialPort.getCommPorts();
        String port = "";
        
        // ist ein bekanntes Arduino dabei ?
        for ( SerialPort sp : serialPorts )
        {
            String portname = sp.getSystemPortName();
            String portdesc = sp.getDescriptivePortName();
            //         Original Arduino         oder     ein China-Imitat       oder    anderes China-Imitat
            if ( portdesc.contains( "Arduino" )  ||  portdesc.contains("CH340")  ||  portdesc.contains("ch341") )
            {
                port = portname;
                System.out.println("Arduino: " + portdesc + " an port " + portname);
            }
        }
        
        // ToDo:    iOS-Bezeichnung fuer MAC ergaenzen !!!
        
        // LINUX-Hack: getSystemPortname() liefert nicht den vollstaendigen Pfad ==> ergaenzen
        if ( !port.isEmpty() )
        {
            if  ( port.contains("tty") )
                {
                    port = "/dev/"+port;
                }
        }
        
        // mit dem Device verbinden
        try
        {
            device = new FirmataDevice( port );
            device.start();
            pause(5000);
            System.out.println( device.getPinsCount() + " Pins erkannt");
            
            // fuer Arduino UNO
            if  ( device.getPinsCount() == 20 )
            {
                System.out.println("Es handelt sich um ein Arduino Uno");
                device.ensureInitializationIsDone();
            }
            // fuer Arduino Mega 2560
            else
            {
                System.out.println("Es handelt sich um ein Arduino Mega - EXPERIMENTAL");
                try
                {
                    device.ensureInitializationIsDone();
                }
                catch ( InterruptedException e )
                {
                    System.out.println( e.getMessage() );
                    e.printStackTrace();
                }
            }
        }
        catch ( IOException e)
        {
            System.out.println("Keine Firmata-Software gefunden :-(");
            e.printStackTrace();
        }
        catch ( InterruptedException e )
        {
            System.out.println("Initialisierung wurde unterbrochen :-(");
            e.printStackTrace();
        }
    }

    
    
    /**
     * Stoppt das Arduino-Device endgueltig.
     */
    public static void stop()
    {
        try
        {
            device.stop();
        }
        catch ( IOException e)
        {
            e.printStackTrace();
        }
    }

    
    
    /**
     * Gibt Zugriff auf das Arduino-Device.
     *
     * @return  Referenz auf das Arduino-Device
     */
    public static IODevice getDevice()
    {
        if ( device == null )
        {
            setup();
        }
        return device;
    }

    
    
    /**
     * Setzt den Modus (Sinn / Zweck) des Pins.
     *
     * @param   pin     Nummer des Pins am Arduino (2-19 beim UNO, ab 14 analog) (2-69 beim Mega, ab 54 analog)
     * @param   mode    INPUT (0) , OUTPUT (1) , ANALOG (2) , PWM (3) , SERVO (4) , PULLUP (5)
     */
    public static void setMode( int pin, int mode )
    {
        try
        {
            if ( mode == INPUT )
            {
                device.getPin( pin ).setMode( Pin.Mode.INPUT );
            }
            else if ( mode == OUTPUT )
            {
                device.getPin( pin ).setMode( Pin.Mode.OUTPUT );
            }
            else if ( mode == PWM )
            {
                device.getPin( pin ).setMode( Pin.Mode.PWM );
            }
            else if ( mode == ANALOG )
            {
                device.getPin( pin ).setMode( Pin.Mode.ANALOG );
            }
            else if ( mode == SERVO )
            {
                device.getPin( pin ).setMode( Pin.Mode.SERVO );
            }
            else if ( mode == PULLUP )
            {
                device.getPin( pin ).setMode( Pin.Mode.PULLUP );
            }
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }

    
    
    /**
     * Setzt den Wert eines digitalen Ausgangs-Pins.
     *
     * @param   pin     Nummer des Pins am Arduino (2-13 beim UNO) (2-53 beim Mega)
     * @param   value   LOW (0) , HIGH (1)
     */
    public static void write ( int pin , int value )
    {
        try
        {
            device.getPin( pin ).setValue( value );
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }

    
    
    /**
     * Liest den Wert eines digitalen Eingangs.
     *
     * @param   pin     Nummer des Pins am Arduino (2-13 beim UNO) (2-53 beim Mega)
     * @return          false (LOW) , true (HIGH)
     */
    public static boolean read_digital( int pin )
    {
        if  ( device.getPin( pin ).getValue() == 0 )
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    
    
    /**
     * Liest den Wert eines analogen Eingangs.
     * 
     * @param   pin     Nummer des Pins am Arduino (14-19 beim UNO) (54-69 beim Mega)
     * @return          0 (GND) bis 1023 (5V)
     */
    public static long read_analog( int pin )
    {
        return device.getPin( pin ).getValue();
    }

    
    
    /**
     * Meldet einen Observer am Pin an.
     *
     * @param   pin     Nummer des Pins am Arduino Uno (sinnvoll 2-13) (zweifelhaft sinnvoll 14-19), 
     *                                     Arduino Mega (sinnvoll 2-59) (zweifelhaft sinnvoll 54-69)
     * @param   pel     Referenz auf ein Objekt, dessen Klasse des Interface org.firmata4j.PinEventListener implementiert
     */
    public static void addEventListener ( int pin , PinEventListener pel )
    {
        device.getPin( pin ).addEventListener( pel );
    }

    
    
    /**
     * Entfernt einen Event-Listener wieder.
     *
     * @param   pin     Nummer des Pins am Arduino
     * @param   pel     Referenz auf ein Objekt, dessen Klasse des Interface org.firmata4j.PinEventListener implementiert
     */
    public static void removeEventListener ( int pin , PinEventListener pel )
    {
        device.getPin( pin ).removeEventListener( pel );
    }

    
    
    /**
     * Wartet fuer einige Milli-Sekunden.
     *
     * @param milli_sec Ein Parameter
     */
    public static void pause( int milli_sec )
    {
        try
        {
            Thread.sleep( milli_sec );
        }
        catch ( InterruptedException e )
        {
            e.printStackTrace();
        }
    }
}
