import org.firmata4j.*;
import java.io.*;

/**
 * PinInput repraesentiert einen digitalen Eingangs-Pin, 
 * der selbst als eigener Listener agiert. 
 * 
 * Verwendung 1:
 * Erbe von dieser Klasse und ueberschreibe die Methoden 
 * onReceiveChange() , onReceiveHigh() , onReceiveLow()
 * 
 * Verwendung 2:
 * Referenziere diese Klasse und verwende die Methoden 
 * isHigh() , isLow()
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.2 (2017-08-07)    PullUp Widerstand realisiert, Unterstuetzung fuer Mega
 *              1.1 (2017-01-04)    Entprellen realisiert
 *              1.0 (2017-01-01)    initial
 */
public class PinInput
// Jede beliebige Klasse kann das Interface implementieren
implements PinEventListener
{
    private Pin pin_input;
    
    // zum Entprellen
    protected volatile boolean changed;
    protected int debounce_interval;
    
    // speichert den letzten Zustand, der vom Listener gemeldet wurde
    protected boolean state;

    
    /**
     * Konstruktor der Klasse PinInput (ohne PullUp Widerstand).
     * 
     * @param   pin     Nummer des Pins am Arduino (2-13 beim UNO)
     */
    public PinInput( int pin )
    {
        try
        {
            this.pin_input = Arduino.getDevice().getPin( pin );
            this.pin_input.setMode( Pin.Mode.INPUT );
            this.changed = false;
            this.debounce_interval = 0;
            this.state = false;
            pin_input.addEventListener( this );
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    
    /**
     * Konstruktor der Klasse PinInput (mit PullUp Widerstand).
     * 
     * @param   pin     Nummer des Pins am Arduino (2-13 beim UNO) (2-53 beim Mega) 
     * @param   pullup  'true' fuer einen PullUp Widerstand, 'false' fuer keinen 
     */
    public PinInput( int pin , boolean pullup )
    {
        try
        {
            this.pin_input = Arduino.getDevice().getPin( pin );
            if ( pullup == false )
            {
                this.pin_input.setMode( Pin.Mode.INPUT );
            }
            else
            {
                this.pin_input.setMode( Pin.Mode.PULLUP );
            }
            this.changed = false;
            this.debounce_interval = 0;
            this.state = false;
            pin_input.addEventListener( this );
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }
    

    
    /**
     * Prueft, ob der Eingangs-Pegel HIGH ist
     *
     * @return  true fuer HIGH, false fuer LOW
     */
    public boolean isHigh()
    {
        return this.state;
    }

    
    
    /**
     * Prueft, ob der Eingangs-Pegel LOW ist
     *
     * @return  true fuer LOW, false fuer HIGH
     */
    public boolean isLow()
    {
        return !this.state;
    }

    
    
    /**
     * Entprellen des digitalen Eingangs-Pin einstellen oder abschalten.
     *
     * @param   milli_sec   Anzahl an Millisekunden, die nach einem Flanken-Wechsel 
     *                      nicht mehr auf weitere Flanken-Wechsel reagiert werden soll. 
     *                      Wert 0 bedeutet: kein Entprellen
     */
    public void setDebounce( int milli_sec )
    {
        this.debounce_interval = milli_sec;
    }

    
    
    // Methoden, die von dem Interface gefordert werden

    
    // Reaktion auf Sinn-Wechsel: Input / Output
    @Override
    public void onModeChange ( IOEvent event ) 
    {
        // Hier dein Code
    }

    
    
    // Reaktion auf Flanken-Wechsel
    @Override
    public void onValueChange ( IOEvent event ) 
    {
        // Mechanismus zum entprellen - Teil 1
        if  ( !this.changed )
        {
            if  ( this.debounce_interval > 0 )
            {
                this.changed = true;
            }
        // -----------------------------------

            // Bei jedem Flanken-Wechsel
            onReceiveChange();

            // nur bei  HIGH --> LOW
            if  ( event.getPin().getValue() == 0 )
            {
                this.state = false;
                onReceiveLow();
            }

            // nur bei  LOW --> HIGH
            else
            {
                this.state = true;
                onReceiveHigh();
            }

            // Mechanismus zum Entprellen - Teil 2
            if  ( this.debounce_interval > 0 )
            {
                Thread t = new Thread ( ) 
                    {
                        @Override
                        public void run()
                        {
                            try
                            {
                                Thread.sleep( debounce_interval );
                                changed = false;
                            }
                            catch( InterruptedException e )
                            {
                                e.printStackTrace();
                            }
                        }
                    };
                t.start();
            }
            // ------------------------------------
        }
    }
    
    
    
    // Diese Methoden koennen von Subklassen ueberschreiben werden
    
    /**
     * Wenn ein Flanken-Wechsel LOW --> High erfolgt. 
     * Subklassen ueberschreiben diese Methode bei Bedarf.
     */
    public void onReceiveHigh()
    {
        // System.out.println("Flanken-Anstieg");
    }
    
    
    /**
     * Wenn ein Flanken-Wechsel High --> LOW erfolgt. 
     * Subklassen ueberschreiben diese Methode bei Bedarf.
     */
    public void onReceiveLow()
    {
        // System.out.println("Flanken-Abfall");
    }
    
    
    /**
     * Wenn ein Flanken-Wechsel irgend einer Art erfolgt. 
     * Subklassen ueberschreiben diese Methode bei Bedarf.
     */
    public void onReceiveChange()
    {
        // System.out.println("Flanken-Wechsel");
    }

    
}
