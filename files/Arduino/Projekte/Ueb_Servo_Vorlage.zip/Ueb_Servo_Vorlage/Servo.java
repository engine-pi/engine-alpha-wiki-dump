import org.firmata4j.*;
import java.io.*;

/**
 * Servo repraesentiert einen PWM-Pin am Arduino, 
 * der speziell fuer den Betrieb eines Servo-Motors vorbereitet wurde. 
 * Leider dreht sich der Servo nur um 120 Grad, obwohl es 180 Schritte gibt. 
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.1 (2017-08-08)    Geschwindigkeits-Regelung durch Methode 'setPause(...)'
 *              1.0 (2017-04-12)    initial
 */
public class Servo
{
    private Pin servo_pin;
    private int delay;
    private int left;
    private int right;
    private int center;

    
    /**
     * Konstruktor der Klasse Servo.
     * 
     * @param   pin     Nummer des Pins am Arduino ( 3 , 5 , 6 , 9 , 10 , 11 beim UNO)
     */
    public Servo( int pin )
    {
        this.servo_pin = Arduino.getDevice().getPin( pin );
        try
        {
            this.servo_pin.setMode( Pin.Mode.SERVO );
            Arduino.pause( 250 );
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
        this.delay = 20;
        this.left = 1;
        this.right = 179;
        this.center = (this.left + this.right) / 2;
        this.setValue( this.center );
    }
    
    
    
    /**
     * Stellt ein, wie schnell sich der Servo auf die neue Position bewegt. 
     *
     * @param   delay   Standard = 20 ; kleiner = schneller ; groesser = langsamer
     */
    public void setDelay( int delay )
    {
        if ( delay < 0 )
        {
            this.delay = 0;
        }
        else
        {
            this.delay = delay;
        }
    }
    
    
    
    /**
     * Left den Wert fuer 'value' fest, mit dem man nach ganz links dreht. 
     * Der Wert fuer 'center' wird automatisch angepasst. 
     *
     * @param   left    Standard = 1 (<0 ergibt 0 ; >180 ergibt 180)
     */
    public void setLeft( int left )
    {
        if ( left < 0 )
        {
            this.left = 0;
        }
        else if ( left > 180 )
        {
            this.left = 180;
        }
        else
        {
            this.left = left;
        }
        
        this.center = (this.left + this.right) / 2;
    }
    
    
    
    /**
     * Left den Wert fuer 'value' fest, mit dem man nach ganz rechts dreht. 
     * Der Wert fuer 'center' wird automatisch angepasst. 
     *
     * @param   right Standard = 179 (<0 ergibt 0 ; >180 ergibt 180)
     */
    public void setRight( int right )
    {
        if ( right < 0 )
        {
            this.right = 0;
        }
        else if ( right > 180 )
        {
            this.right = 180;
        }
        else
        {
            this.right = right;
        }
        
        this.center = (this.left + this.right) / 2;
    }

    
    
    /**
     * Setzt den Wert fuer den Servo. 
     *
     * @param   value   Wert von 0 bis 180
     */
    public void setValue( int value )
    {
        if  ( value < this.left )
        {
            value = this.left;
        }
        else if  ( value > this.right )
        {
            value = this.right;
        }
        int akt_value = (int)this.getValue();
        try
        {
            if (akt_value>value)
        {
            for ( int i=akt_value ; i>value ; i--)
            {
                this.servo_pin.setValue( i );
                Arduino.pause( this.delay );
            }
        }
        else 
        {
            for ( int i=akt_value ; i<value ; i++)
            {
                this.servo_pin.setValue( i );
                Arduino.pause( this.delay );
            }
        }
            
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }
    
    
    
    /**
     * Gibt den aktuellen Wert des Servos zurueck.
     *
     * @return      Wert zwischen 0 und 180
     */
    public long getValue()
    {
        return this.servo_pin.getValue();
    }
    
    
    
    /**
     * Dreht den Servo ganz nach links.
     */
    public void left()
    {
        this.setValue( this.left );
    }
    
    
    /**
     * Dreht den Servo ganz nach rechts.
     */
    public void right()
    {
        this.setValue( this.right );
    }
    
    
    /**
     * Dreht den Servo mittig.
     */
    public void center()
    {
        this.setValue( this.center );
    }
    
    
}
