import org.firmata4j.*;
import java.io.*;

/**
 * PinAnalog repraesentiert einen analogen Eingangs-Pin am Arduino.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.1 (2017-08-07)    Unterstuetzung fuer Mega
 *              1.0 (2017-01-04)    initial
 */
public class PinAnalog
{
    private Pin analog_pin;

    
    /**
     * Konstruktor der Klasse PinAnalog.
     * 
     * @param   pin Nummer des Arduino-PINs (13-19 beim Uno) (53-69 beim Mega)
     */
    public PinAnalog( int pin )
    {
        this.analog_pin = Arduino.getDevice().getPin( pin );
        try
        {
            this.analog_pin.setMode( Pin.Mode.ANALOG );
        }
        catch ( IOException e )
        {
            e.printStackTrace();
        }
    }

    
    /**
     * Liefert den am analogen Eingangs-Pin anliegenden Pegel.
     *
     * @return  Wert von 0 bis 1023
     */
    public long readValue()
    {
        return this.analog_pin.getValue();
    }
}
