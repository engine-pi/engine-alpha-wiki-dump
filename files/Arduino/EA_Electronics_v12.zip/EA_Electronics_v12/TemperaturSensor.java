
/**
 * TemperaturSensor repraesentiert eine Reihenschaltung aus 10k-NTC (GND) und 10k-Widerstand (5V). 
 * Die Messung erfolgt zwischen den beiden Bauteilen. 
 * Der analoge Roh-Wert wird umgerechnet in Grad Celsius. 
 * Es kann eine absolute Korrektur in 1/10 Grad Celsius vorgenommen werden.
 * 
 * (Der Sensor verhaelt sich im Bereich 0 - 50 Grad Celsius nahezu linear.) 
 * 
 * ---------------
 *  PRAXIS - TIPP
 * ----------------------------------------------------------------------------------
 * Fuer sehr praezise Messungen wird empfohlen, die Spannungs-Versorgung (5V) 
 * nicht dauerhaft sondern sehr zeitnah über einen digitalen OUTPUT anzulegen: 
 * Sensor an , 2 Millisekunden warten , Messung , Sensor aus
 * Damit wird Erwaermung des Sensors durch den unvermeidlichen Stromfluss vermieden.
 * ----------------------------------------------------------------------------------
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-01-05)    initial
 */
public class TemperaturSensor
{
    // 10k-NTC (GND) in Reihe zu einem 10k-Widerstand (5V) und Abgriff mittig
    private PinAnalog spannungsteiler;
    // Damit kann man den absoluten Temperatur-Wert kalibirieren
    private float tempShift;

    
    /**
     * Konstruktor der Klasse TemperaturSensor
     * 
     * @param   pin     Nummer des PINs am Arduino ( 14 - 19 am UNO )
     */
    public TemperaturSensor( int pin )
    {
        this.spannungsteiler = new PinAnalog( pin );
        this.tempShift = 0;
    }

    
    /**
     * Gibt die Temperatur in Grad Celsius auf eine NAchkommastelle genau zurueck. 
     *
     * @return      Temperatur in Grad Celsius auf eine Nachkommastelle genau
     */
    public float getCelsius()
    {
        // Wert aus empirischen eigenen Messungen
        double celsius = (( 1.0*this.spannungsteiler.readValue() - 237 ) / 11.9634) + tempShift;
        return (float)( Math.round(10.0*celsius)/10.0 );
    }
    
    
    public void setTempShift( float tempShift )
    {
        this.tempShift = tempShift;
    }
}
