
/**
 * JoystickDemoA demonstriert die Funktionsweise eines analogen Josticks 
 * in Verbindung mit der Engine Alpha. 
 * Der x-Pin muss an Pin-14 (A0) und der y-Pin an Pin-15 (A1) angelegt sein. 
 * 
 * @author      mike_gans@yahoo.de 
 * 
 * @version     1.0 (2017-01-06)
 */
public class JoystickDemoA 
extends SPIEL
{
    private BILD bild;
    private JoystickAnalog js;

    
    /**
     * Konstruktor der Klasse MeinSpiel
     */
    public JoystickDemoA()
    {
        super(512,512,false,false,false);
        super.tickerStoppen();
        this.bild = new BILD(256,256,"ball.png");
        this.js = new JoystickAnalog(14,15,4);
        super.tickerNeuStarten(50);
    }

    
    @Override
    public void tick()
    {
        this.bild.setzeMittelpunkt( (int)(this.js.getX()/2), (int)(this.js.getY()/2) );
    }
}
