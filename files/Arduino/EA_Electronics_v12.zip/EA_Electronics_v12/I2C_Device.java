import org.firmata4j.I2CDevice;
import org.firmata4j.I2CListener;
import org.firmata4j.I2CEvent;
import java.io.IOException;


/**
 * Klasse I2C_Element repraesentiert einen Sensor oder Aktor, 
 * der ueber den I2C-Bus angesprochen wird. 
 * 
 * Diese Klasse arbeitet noch auf der technischen I2C-Protokoll-Ebene. 
 * Jeder Konkrete Sensor sollte eine Referenz dieses Typs verwalten und 
 * nach aussen sprechende Methoden zur Verfuegung stellen, fuer deren 
 * Realisierung das Datenblatt nnoetig ist.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (20017-08-07)   initial
 */
public class I2C_Device 
implements I2CListener
{
    private I2CDevice i2cDevice = null;
    private byte[] receivedData;
    

    /**
     * Konstruktor der (noch sehr experimentellen) Klasse I2C_Device
     * 
     * @param   i2c_adresse     I2C-Adresse des Devices, z.B. 0x3C
     */
    public I2C_Device( int i2c_adresse )
    {
        try
        {
            this.i2cDevice = Arduino.getDevice().getI2CDevice( (byte)i2c_adresse );
        }
        catch (IOException e)
        {
            System.out.println( "----- I2C-Device nicht gefunden! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    
    // --------------------
    
    /**
     * Gibt die I2C-Adresse des Devices zurueck. 
     *
     * @return  I2C-Adresse des Devices
     */
    public byte getAddress()
    {
        return this.i2cDevice.getAddress();
    }
    
    // --------------------
    
    /**
     * Vom Interface I2CListener geforderte Methode um automatisch auf Signale des I2C-Devices zu reagieren.
     * Dies ist immer der Fall, wenn einzeln oder fortwaehrend Messwerte angefordert werden. 
     *
     * @param   e   Automatisch uebergebenes Event, das im Rumpf weiter abgefragt werden kann
     */
    @Override
    public void onReceive( I2CEvent e )
    {
        this.receivedData = e.getData();
    }
    
    
    /**
     * Gibt das letzte empfangene Byte-Array des Devices zurueck. 
     *
     * @return  Byte-Array mit den letzten vom Device empfangenen Daten
     */
    public byte[] getData()
    {
        return this.receivedData;
    }
    
    // --------------------
    
    /**
     * Sendet ein Byte-Array bzw. eine Folge von Bytes an das Device. 
     *
     * @param   data    Byte-Array bzw. Folge von Bytes
     */
    public void tell(byte... data)
    {
        try
        {
            this.i2cDevice.tell( data );
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    
    /**
     * Erfragt einmalig einen Messwert des I2C-Devices. 
     * Dieser wird automatisch von der Methode 'onReceive()' empfangen. 
     * Die Antwort kann (nach minimaler Wartezeit) durch 'getValue()' abgefragt werden.
     *
     * @param   responseLength  Laenge der erwarteten Antwort in Byte (?)
     */
    public void ask( byte responseLength )
    {
        try
        {
            this.i2cDevice.ask( responseLength , this );
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    
    /**
     * Erfragt einmalig einen Messwert des I2C-Devices aus einem bestimmten Register. 
     * Dieser wird automatisch von der Methode 'onReceive()' empfangen. 
     * Die Antwort kann (nach minimaler Wartezeit) durch 'getValue()' abgefragt werden.
     *
     * @param   register        Nummer des abzufragenden Registers als Integer
     * @param   responseLength  Laenge der erwarteten Antwort in Byte (?)
     */
    public void ask( int register , byte responseLength)
    {
        try
        {
            this.i2cDevice.ask( register , responseLength , this );
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    // --------------------
    
    /**
     * Meldet dieses Objekt als Listener beim I2C-Device an. 
     * Automatische Updates werden empfangen, sobald anschliessend die 
     * Methode 'startReceivingUpdates(...)' aufgerufen wurde.
     *
     */
    public void subscribe()
    {
        this.i2cDevice.subscribe( this );
    }
    
    
    /**
     * Meldet dieses Objekt wieder als Listener beim I2C-Device ab. 
     *
     */
    public void unsubscribe()
    {
        this.i2cDevice.unsubscribe( this );
    }
    
    
    /**
     * Startet den Empfang automatischer Messwerte. 
     * Hierzu muss vorher die Methode 'suscribe()' aufgerufen werden. 
     *
     * @param   messageLength   Laenge der erwarteten Antwort in Byte (?)
     */
    public void startReceivingUpdates( byte messageLength )
    {
        try
        {
            this.i2cDevice.startReceivingUpdates( messageLength );
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    
    /**
     * Stoppt das automatische Empfangen von Messwerten wieder, 
     * ohne dieses Objekt beim I2C-Device abzumelden. 
     *
     */
    public void stopReceivingUpdates()
    {
        try
        {
            this.i2cDevice.stopReceivingUpdates();
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    
    /**
     * Setzt eine Zeit in MilliSekunden, die gewartet werden soll, 
     * bis nach einer Anfrage an das Device eine Antwort gelesen werden kann.
     *
     * @param   delay   Wartezeit in MilliSekunden
     */
    public void setDelay( int delay )
    {
        try
        {
            this.i2cDevice.setDelay( delay );
        }
        catch ( IOException e )
        {
            System.out.println( "----- Kommunikation mit I2C-Device nicht moeglich! -----" );
            e.getMessage();
            e.printStackTrace();
        }
    }
    
    // --------------------
    
}
