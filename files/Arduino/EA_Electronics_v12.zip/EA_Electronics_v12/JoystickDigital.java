
/**
 * JoystickDigital repraesentiert einen 4-Button-Joystick. 
 * Jeder Button steht fuer eine der 4 Himmelsrichtungen.
 * Es wird erwartet, dass die Buttons Hardware-seitig mit 
 * einem PULLUP-Widerstand versehen sind und beim Druecken 
 * den Zustand LOW hervorrufen.
 * 
 * Hardware-Tipp:
 * --------------
 * Von +5V ueber 10kOhm zu einem Anschluss des Buttons, 
 * vom anderen Anschluss des Buttons zu GND. 
 * Zwischen Widerstand und Taster geht es zum Arduino.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-01-07)    initial
 */
public class JoystickDigital
{
    private JoystickButton button_up;
    private JoystickButton button_down;
    private JoystickButton button_left;
    private JoystickButton button_right;
    

    /**
     * Konstruktor der Klasse JoystickDigital. 
     * 
     * @param   pin_up      Nummer des Pins am Arduino fuer den UP-Button
     * @param   pin_left    Nummer des Pins am Arduino fuer den LEFT-Button
     * @param   pin_down    Nummer des Pins am Arduino fuer den DOWN-Button
     * @param   pin_right   Nummer des Pins am Arduino fuer den RIGHT-Button
     */
    public JoystickDigital( int pin_up , int pin_left , int pin_down , int pin_right )
    {
        this.button_up    = new JoystickButton( pin_up    , 'u' , this );
        this.button_down  = new JoystickButton( pin_down  , 'd' , this );
        this.button_left  = new JoystickButton( pin_left  , 'l' , this );
        this.button_right = new JoystickButton( pin_right , 'r' , this );
    }

    
    // Methoden fuer die Subklassen zum Ueberschreiben --------------------
    
    /**
     * Reaktion auf UP - Subklassen ueberschreiben diese Methode.
     */
    public void up()
    {
        System.out.println("UP");
    }
    
    
    /**
     * Reaktion auf DOWN - Subklassen ueberschreiben diese Methode.
     */
    public void down()
    {
        System.out.println("DOWN");
    }
    
    
    /**
     * Reaktion auf LEFT - Subklassen ueberschreiben diese Methode.
     */
    public void left()
    {
        System.out.println("LEFT");
    }
    
    
    /**
     * Reaktion auf RIGHT - Subklassen ueberschreiben diese Methode.
     */
    public void right()
    {
        System.out.println("RIGHT");
    }
    
    // ---------- Ende Methoden zum Ueberschreiben ------------------------------
    
    
    /**
     * Entprellt die Buttons.
     *
     * @param   milli_sec   Zeit in Millisekunden, die nach einem Button-Druck verstreicht, 
     *                      bis ein neues Button-Event registriert wird. (Standard 10)
     */
    public void setDebounce( int milli_sec )
    {
        this.button_up.setDebounce( milli_sec );
        this.button_left.setDebounce( milli_sec );
        this.button_down.setDebounce( milli_sec );
        this.button_right.setDebounce( milli_sec );
    }
}





/**
 * Hilfs-Klasse JoystickButton repraesentiert einen Button des digitalen Joysticks.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-01-07)
 */
class JoystickButton 
extends PinInput
{
    private JoystickDigital joystick;
    private char direction;
    
    
    /**
     * Konstruktor der Klasse JoystickButton. 
     *
     * @param   pin         Nummer des Pins am Arduino (2-13 beim UNO)
     * @param   direction   n s e w (north south east west) oder u d l r (up down left right)
     * @param   js          Referenz auf das Joystick-Objekt, welches diesen Button benutzt.
     */
    public JoystickButton( int pin , char direction , JoystickDigital js )
    {
        super( pin );
        super.setDebounce( 10 );
        this.joystick = js;
        this.direction = direction;
    }
    
    
    
    @Override
    /**
     * Geerbte Methode ueberschreiben um auf Button-Druck zu reagieren. 
     */
    public void onReceiveLow()
    {
        // North | Up
        if  ( this.direction == 'n'  ||  this.direction == 'N'  ||  this.direction == 'u'  ||  this.direction == 'U' )
        {
            this.joystick.up();
        }
        // South | Down
        else if  ( this.direction == 's'  ||  this.direction == 'S'  ||  this.direction == 'd'  ||  this.direction == 'D' )
        {
            this.joystick.down();
        }
        // East | Right
        else if  ( this.direction == 'e'  ||  this.direction == 'E'  ||  this.direction == 'r'  ||  this.direction == 'R' )
        {
            this.joystick.right();
        }
        // West | Left
        else if  ( this.direction == 'w'  ||  this.direction == 'W'  ||  this.direction == 'l'  ||  this.direction == 'L' )
        {
            this.joystick.left();
        }
    }
    
    
}


