
/**
 * JoystickAnalog repraesentiert einen analogen Joystick. 
 * Dieser verfuegt ueber 2 analoge Eingaenge fuer x und y 
 * und einen digitalen Eingang fuer den Push-Button.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-04-11)    initial
 */
public class JoystickAnalog 
{
    private PinAnalog x;
    private PinAnalog y;
    private PinInput button;
    

    /**
     * Konstruktor der Klasse JoystickAnalog (ohne Push-Button). 
     * Bei dieser Art Joystick gibt es 2 analoge Signale fuer die x- bzw- y-Koordinate.
     * 
     * @param   pin_x          Nummer des analogen Pins am Arduino (14-19 beim UNO)
     * @param   pin_y          Nummer des analogen Pins am Arduino (14-19 beim UNO)
     */
    public JoystickAnalog( int pin_x , int pin_y )
    {
        this.x = new PinAnalog( pin_x );
        this.y = new PinAnalog( pin_y );
    }
    
    /**
     * Konstruktor der Klasse JoystickAnalog (mit Push-Button). 
     * Bei dieser Art Joystick gibt es 2 analoge Signale fuer die x- bzw- y-Koordinate 
     * und einen digitalen Pin fuer den Push-Button.
     * 
     * @param   pin_x          Nummer des analogen Pins am Arduino (14-19 beim UNO)
     * @param   pin_y          Nummer des analogen Pins am Arduino (14-19 beim UNO)
     * @param   pin_button     Nummer des digitalen Pins am Arduino (2-13 beim UNO)
     */
    public JoystickAnalog( int pin_x , int pin_y , int pin_button )
    {
        this( pin_x , pin_y );
        this.button = new PinInput( pin_button );
    }
    
    
    /**
     * Fragt den x-Wert des Joysticks ab.
     *
     * @return  Wert zwischen 0 und 1023
     */
    public long getX()
    {
        return this.x.readValue();
    }
    
    
    /**
     * Fragt den y-Wert des Joysticks ab.
     *
     * @return  Wert zwischen 0 und 1023
     */
    public long getY()
    {
        return this.y.readValue();
    }
    
    
    /**
     * Fragt den Zustand des Push-Buttons ab.
     *
     * @return  true, wenn der Button gedrueckt ist
     */
    public boolean isPressed()
    {
        return this.button.isLow();
    }
}
