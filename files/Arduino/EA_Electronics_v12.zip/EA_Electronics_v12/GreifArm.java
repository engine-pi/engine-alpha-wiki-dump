
/**
 * Greifarm mit 3 Servos: Hand / rauf, runter / links, rechts .
 * VORSICHT !!!
 * Immer erst bei jedem Servo den Werte-Bereich langsam austesten !!!
 * 
 * @author      mike ganshorn
 * 
 * @version     1.0 (2017-04-12)
 */
public class GreifArm
{
    private Servo Hand;
    private Servo Kipper;
    private Servo Schwenker;

    
    /**
     * Konstruktor der Klasse GreifArm. 
     * 
     * Verwendete Pins: Hand=3, Kipper=5, Schwenker=6;
     */
    public GreifArm()
    {
        this( 3 , 5 , 6 );
    }

    
    /**
     * Konstruktor der Klasse GreifArm. 
     * 
     * @param   pin_hand         Arduino-Pin des Hand-Servo ( 3 , 5 , 6 , 9 , 10 , 11 beim UNO)
     * @param   pin_kipper       Arduino-Pin des Hand-Servo ( 3 , 5 , 6 , 9 , 10 , 11 beim UNO)
     * @param   pin_schwenker    Arduino-Pin des Hand-Servo ( 3 , 5 , 6 , 9 , 10 , 11 beim UNO)
     */
    public GreifArm( int pin_hand , int pin_kipper , int pin_schwenker )
    {
        this.Hand = new Servo(pin_hand);
        this.Hand.setValue(120);      // fast zu
        this.Kipper = new Servo(pin_kipper);
        this.Kipper.setValue(145);    // senkrecht
        this.Schwenker = new Servo(pin_schwenker);
        this.Schwenker.setValue(95);  // mittig
    }
    
    
    
    /**
     * Bewegt den Kipper so weit runter, dass die geschlossene Hand gerade nicht den Klotz beruehrt.
     *
     */
    public void kipper_klotz()
    {
        this.Kipper.setValue( 50 );
    }
    
    /**
     * Bewegt den Kipper so weit runter, dass die geschlossene Hand gerade nicht den Boden beruehrt.
     *
     */
    public void kipper_boden()
    {
        this.Kipper.setValue( 25 );
    }
    
    /**
     * Bewegt den Kipper so , dass die Hand waagerecht steht.
     *
     */
    public void kipper_waagerecht()
    {
        this.Kipper.setValue( 70 );
    }
    
    /**
     * Bewegt den Kipper so weit hoch, dass die Hand senkrecht steht.
     *
     */
    public void kipper_rauf()
    {
        this.Kipper.setValue( 145 );
    }
    
    
    
    /**
     * Macht die Hand ganz auf (ca. 5cm).
     *
     */
    public void hand_auf()
    {
        this.Hand.setValue( 80 );
    }
    
    /**
     * Macht die Hand fast ganz zu (ca. 0,5cm).
     *
     */
    public void hand_zu()
    {
        this.Hand.setValue( 130 );
    }
    
    
    
    /**
     * Dreht den Schwenker zum Klotz.
     *
     */
    public void schwenker_klotz()
    {
        this.Schwenker.setValue( 175 );
    }
    
    /**
     * Dreht den Schwenker zur Mitte.
     *
     */
    public void schwenker_mitte()
    {
        this.Schwenker.setValue( 95 );
    }
    
    /**
     * Dreht den Schwenker vom Klotz weg.
     *
     */
    public void schwenker_weg_vom_klotz()
    {
        this.Schwenker.setValue( 25 );
    }
    
    
    
    public void test()
    {
        this.hand_auf();
        this.schwenker_klotz();
        this.kipper_klotz();
        this.hand_zu();
        this.kipper_rauf();
        this.schwenker_weg_vom_klotz();
        this.kipper_boden();
        this.hand_auf();
        this.kipper_rauf();
        this.schwenker_mitte();
    }
}
