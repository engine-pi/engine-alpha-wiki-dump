
/**
 * DimmableLED repraesentiert eine LED, die an einen PWM-Port des Arduino angeschlossen ist.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-04-11)    initial
 */
public class DimmableLED
extends PinPWM
{
    

    /**
     * Konstruktor der Klasse DimmableLED
     * 
     * @param   pin Nummer des Pins am Arduino ( 3 , 5 , 6 , 9 , 19 , 11 beim UNO )
     */
    public DimmableLED( int pin )
    {
        super( pin );
    }

    
    
    /**
     * Setzt die Helligkeit der LED in Prozent.
     *
     * @param   percentage      Ein Wert von 0 bis 100
     */
    public void setBrightness( int percentage )
    {
        super.setDutyCyclePercentage( percentage );
    }
    
    
    
    /**
     * Nennt den aktuellen Helligkeits-Wert in Prozent.
     *
     * @return      Aktuelle Helligkeit in Prozent
     */
    public int getBrightness()
    {
        return super.getDutyCyclePercentage();
    }
    
    
    
    /**
     * Macht die LED heller, falls es noch geht.
     */
    public void moreBrightness()
    {
        int brightness = super.getDutyCyclePercentage() + 10;
        if ( brightness > 100 )
        {
            brightness = 100;
        }
        super.setDutyCyclePercentage( brightness );
    }
    
    
    
    /**
     * Macht die LED dunkler, falls es noch geht.
     */
    public void lessBrightness()
    {
        int brightness = super.getDutyCyclePercentage() - 10;
        if ( brightness < 0 )
        {
            brightness = 0;
        }
        super.setDutyCyclePercentage( brightness );
    }
    
    
    
    /**
     * Schaltet die LED auf macimale Helligkeit.
     */
    public void on()
    {
        this.setBrightness( 100 );
    }
    
    
    
    /**
     * Schaltet die LED ganz aus.
     */
    public void off()
    {
        this.setBrightness( 0 );
    }
    
    
    
    /**
     * Dimmt eine LED langsam an.
     *
     * @param   sec     Anzahl der Sekunden, bis die LED ganz hell ist
     */
    public void dimmUp( int sec )
    {
        this.off();
        
        for ( int i = this.getBrightness() ; i<=100 ; i++ )
        {
            this.setBrightness( i );
            Arduino.pause( 10 * sec );
        }
    }
    
    
    
    /**
     * Dimmt eine LED langsam aus.
     *
     * @param   sec     Anzahl der Sekunden, bis die LED ganz dunkel ist
     */
    public void dimmDown( int sec )
    {
        this.on();
        
        for ( int i = this.getBrightness() ; i>=0 ; i-- )
        {
            this.setBrightness( i );
            Arduino.pause( 10 * sec );
        }
    }
}
