
/**
 * KlatschLicht repraesentiert eine LED, die durch Klatschen ein / aus geschaltet werden kann.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-01-05)    initial
 * 
 */
public class KlatschLicht
extends PinInput
{
    private PinOutput led;

    
    /**
     * Konstruktor der Klasse KlatschSensor
     */
    public KlatschLicht( int input_pin , int led_pin )
    {
        // geerbten Eingangs-Pin initialisieren
        super( input_pin );
        // Prellen am Eingangs-Pin (mehrfaches Rauf/Runter der Schallwelle) vermeiden
        super.setDebounce( 200 );
        
        this.led = new PinOutput( led_pin );
    }

    
    // geerbte Methode ueberschreiben um auf Flanken-Wechsel am Eingang reagieren zu koennen
    
    @Override    
    /**
     * Wird automatisch aufgerufen, sobald ein LOW --> HIGH stattfindet
     *
     */
    public void onReceiveHigh()
    {
        this.led.toggle();
    }
}
