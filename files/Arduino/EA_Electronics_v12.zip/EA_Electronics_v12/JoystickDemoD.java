
/**
 * JoystickDemoD demonstriert die Funktionsweise eines digitalen Josticks 
 * in Verbindung mit der Engine Alpha. 
 * Der Joystick muss folgendermassen angeschlossen werden:
 * UP 13 , RIGHT 12 , DOWN 11 , LEFT 10
 * 
 * Es wird erwartet, dass die Buttons Hardware-seitig mit 
 * einem PULLUP-Widerstand versehen sind und beim Druecken 
 * den Zustand LOW hervorrufen.
 * 
 * Hardware-Tipp:
 * --------------
 * Von +5V ueber 10kOhm zu einem Anschluss des Buttons, 
 * vom anderen Anschluss des Buttons zu GND. 
 * Zwischen Widerstand und Taster geht es zum Arduino.
 * 
 * @author      mike_gans@yahoo.de 
 * 
 * @version     1.0 (2017-01-07)
 */
public class JoystickDemoD 
extends JoystickDigital
{
    private BILD bild;

    /**
     * Konstruktor der Klasse JoystickDemoD
     */
    public JoystickDemoD()
    {
        super( 13 , 12 , 11 , 10 );
        this.bild = new BILD( 400 , 300 , "ball.png" );
    }

    
    @Override
    public void up()
    {
        this.bild.verschiebenUm( 0 , -10 );
    }
    
    @Override
    public void down()
    {
        this.bild.verschiebenUm( 0 , 10 );
    }
    
    @Override
    public void right()
    {
        this.bild.verschiebenUm( 10 , 0 );
    }
    
    @Override
    public void left()
    {
        this.bild.verschiebenUm( -10 , 0 );
    }
}
