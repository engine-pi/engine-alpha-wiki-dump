import ea.*;

/**
 * Dieses Beispiel demonstriert das Einbringen eines Sounds und dessen Abspielen 
 * ueber den <i>Audio-Manager</i> der Klasse <code>Game</code>.<br /><br />
 * 
 * Notiz:<br />
 * Die hier zugehoerige Sound-Datei befindet sich im Projektordner.
 * 
 * @version 2.0
 * @author Michael Andonie
 */
public class Spiel
extends Game {
    
    /**
     * Der abzuspielende Sound
     */
    private Sound sound;
    
    /**
     * Konstruktor-Methode.<br />
     * Hierin wird der Sound geladen und abgespielt. Das Abspielen laesst sich nun ueber die Methoden 
     * veraendern.
     */
    public Spiel() {
        super(500, 400, "Sound-Beispiel");
        
        //Den Sound laden
        //Hierdurch wird er NICHT(!!) abgespielt
        sound = new Sound("sounddatei.wav");
        
        
        
        //Der folgende Quellcode ist eine Alternative zum laden der Datei "sounddatei.wav".
        //Er demonstriert das Nutzen des Pfadtrenners zum Angeben von Ordnern beim Laden
        
        //Soll dieser Benutzt werden, kommentiere am besten die andere Wertzuweisung fuer 
        //das Attribut "sound" aus (Ladezeit!), und kommentiere diese Zeile ein.
        //Er laedt die Datei "laser.wav", die sich 
        //im Verzeichnis "andere_sounds" befindet. Dieses Verzeichnis ist im Projektordner.
        
        //sound = new Sound("andere_sounds" + pfadtrenner + "laser.wav");
        
        
        
        //Den Sound beim Audio-Manager abspielen
        //Abzuspielende Datei: sound
        //Als Dauerschleife abspielen: true      (also ja)
        audioManager.abspielen(sound, true);
    }
    
    /**
     * Diese Methode pausiert den Sound.<br />
     * Wird der Sound nicht abgespielt, gibt es eine Fehlermeldung.
     */
    public void soundPausieren() {
        audioManager.pausieren(sound);
    }
    
    /**
     * Haelt den Sound an.<br />
     * Wird der Sound nicht abgespielt, gibt es eine Fehlermeldung.
     */
    public void soundAnhalten() {
        audioManager.anhalten(sound);
    }
    
    /**
     * Spielt den Sound ab.<br />
     * Wird der Sound bereits abgespielt, gibt die Engine eine Fehlermeldung. Diese Methode kann nach den Methoden 
     * <code>anhalten(Sound sound)</code> bzw. <code>pausieren(Sound sound)</code> ausgefuehrt werden.
     * @param   schleife    Ob der Sound als Dauerschleife abgespielt werden soll.
     */
    public void soundAbspielen(boolean schleife) {
        audioManager.abspielen(sound, schleife);
    }
    
    /**
     * Taste-Reagieren-Methode. Wird in diesem Beispiel nicht verwendet.<br />
     * Sie muss trotzdem implementiert werden, da diese Methode in der Klasse <code>Game</code> eine 
     * abstrakte Methode ist.
     * @param   tastencode  Der Code erlaubt es, jeden Methodenaufruf einer bestimmten Taste zuzuordnen.
     */
    @Override
    public void tasteReagieren(int tastencode) {
        //nicht in Verwendung
    }
}