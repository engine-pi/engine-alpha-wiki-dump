import ea.*;

/**
 * Diese Klasse erstellt eine kleine Umgebung zum Testen der 
 * EA-Physik. Hierbei werden Schwerkraft, Bewegungen, Springen und Reagieren auf zu tiefes Fallen 
 * implementiert.
 * 
 * @version 2.0
 * @author  Michael Andonie
 */
public class Spiel
extends Game 
implements FallReagierbar { //<-Implementieren des Interfaces!!{
    
    /**
     * Die "Ebene"
     */
    private Rechteck ebene;
    
    /**
     * Das "fallende Objekt"
     */
    private Rechteck aktiv;
    
    /**
     * Konstruktor-Methode.<br />
     * Erstellt die Umgebung und setzt Aktiv- und Passiv-Objekte.
     */
    public Spiel() {
        super(400, 400); //<-Aufruf des Konstruktors aus der
                         //Klasse Game (mit Fensterhoehe/-breite)
        //Instanziieren und Einrichten von Ebene und Fallobjekt
        ebene = new Rechteck(0, 300, 200, 10);
        ebene.farbeSetzen("Weiss");
        aktiv = new Rechteck(30, 30, 20, 20);
        aktiv.farbeSetzen("Rot");
        //Anmelden der grafischen Objekte an der Wurzel, um sie
        //sichtbar zu machen!
        wurzel.add(aktiv);
        wurzel.add(ebene);
        
        //Einbringen der Physik
        aktiv.aktivMachen();
        ebene.passivMachen();
        
        //Erstellen einer zusaetzlichen "Mauer"
        Rechteck mauer = new Rechteck(200, 100, 10, 200);
        mauer.farbeSetzen("Weiss");
        wurzel.add(mauer);
        mauer.passivMachen();
        
        //Das FallReagierbar-Interface (=diese Klasse)
        //am roten Quadrat anmelden (kritische Tiefe = 500)
        aktiv.fallReagierbarAnmelden(this, 500);
    }
    
    /**
     * Diese Methode wird aufgerufen, wenn das 
     * rote Quadrat zu tief gefallen ist. Was "zu tief" ist, kann man
     * selbst bestimmen.
     */
    public void fallReagieren() {
        //Das Quadrat wieder nach oben bringen
        aktiv.positionSetzen(30, 30);
        //Zusaetzlich: Die Ebene wieder auf Position bringen
        //(Dadurch faellt das Quadrat nicht ins Leere)
        ebene.positionSetzen(0, 300);
    }
    
    /**
     * Taste-Reagieren-Methode.<br />
     * Hierdrin wird auf den W/A/S/D-Tasten die Bewegung des XX ermoeglich und auf den 
     * Pfeiltaste die Bewegung des .
     * @param   code    Der Code der gedruecken Taste.
     */
    public void tasteReagieren(int code) {
        switch(code) {

            //Bewegung des roten Quadrates
            case 22: //W-Taste
                aktiv.bewegen(0, -10);
                break;
            case 3: //D-Taste
                aktiv.bewegen(10, 0);
                break;
            case 18: //S-Taste
                aktiv.bewegen(0, 10);
                break;
            case 0: //A-Taste
                aktiv.bewegen(-10, 0);
                break;
            
            //Bewegung der Ebene
            case 26: //Pfeil oben
                ebene.bewegen(0, -10);
                break;
            case 27: //Pfeil rechts
                ebene.bewegen(10, 0);
                break;
            case 28: //Pfeil unten
                ebene.bewegen(0, 10);
                break;
            case 29: //Pfeil links
                ebene.bewegen(-10, 0);
                break;
            
            //Sprung des roten Quadrats
            case 30: //Leertaste
                aktiv.sprung(5);
                break;
        }
    }
}